
package pkg17123543.lab2;

/**
 *
 * @author Danial Harith 17123543/1
 */
public interface MoveBehavior {
    public void move();
}
