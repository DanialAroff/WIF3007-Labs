
package pkg17123543.lab2;

/**
 *
 * @author Danial Harith 17123543/1
 */
public class Flying implements MoveBehavior {

    @Override
    public void move() {
        System.out.println("I am flying.");
    }
    
}
